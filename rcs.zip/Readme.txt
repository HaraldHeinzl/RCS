file-name       contents
----------      -------------------------------------

Readme.txt      this information

rcs.mac         SAS-macro RCS

Rcsman.pdf      Manual for the RCS-macro (pdf)

Miller.dat      Stanford Heart Transplant Data as
                printed in Miller and Halpern (1982)

Gehan.dat       Acute leukaemia dataset of Gehan as 
                printed in Hess (1994)

Oakes.dat       Stanford Heart Transplant Data as
                printed in Cox and Oakes (1984)
